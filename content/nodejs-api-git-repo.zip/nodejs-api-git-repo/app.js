const express = require('express');
const app = express();

// Endpoint to return server status and uptime
app.get('/status', (req, res) => {
    res.json({
        status: 'running test 11',
        uptime: process.uptime(), // Uptime in seconds
    });
});


app.get('/health', (req, res) => {
    res.status(200).send('OK');
});


// Start the server on a specific port
const PORT = 3000;
app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server is running on port ${PORT}`);
});

